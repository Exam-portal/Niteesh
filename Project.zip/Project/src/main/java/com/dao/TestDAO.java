package com.dao;

import java.util.List;
import org.aspectj.weaver.ast.Test;

public interface TestDAO {
	
	public void addTest(Test test);
	public Test findTest(int id);
	public List<Test> findAllTest();
	public boolean updateTest(Test test);
	public boolean deleteTest(Test test);
	
	
	

}
