package com.dao;

import java.util.List;

import org.aspectj.weaver.ast.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TestService {
	
	@Autowired
	TestDAO TestDAOImpl;
	
	public void add(Test test) {
		TestDAOImpl.addTest(test);
	}
	
	public Test find(int id) {
		
		return TestDAOImpl.findTest(id);
	}
	public List<Test> findAll() {
		return TestDAOImpl.findAllTest();
	}
	public boolean update(Test test) {
		return TestDAOImpl.updateTest(test);
	}
	public boolean delete(Test test) {
		return TestDAOImpl.deleteTest(test);
	}
	
}
